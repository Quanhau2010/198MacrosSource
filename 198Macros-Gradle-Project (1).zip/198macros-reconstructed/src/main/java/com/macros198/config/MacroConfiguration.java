package com.macros198.config;

import com.macros198.model.MacroCategory;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Represents the runtime configuration and UI metadata of a single macro card,
 * reconstructed from the 168-byte ({@code 0xA8}) struct initialized at {@code 0x140150a30}.
 */
public final class MacroConfiguration {
    private final String name;
    private final String description;
    private final String badgeCode;
    private final MacroCategory category;
    private volatile boolean enabled;
    private volatile String keybind;
    private volatile int delayMs;
    private final Map<String, String> slots;

    public MacroConfiguration(
            String name,
            String description,
            String badgeCode,
            MacroCategory category,
            int defaultDelayMs,
            Map<String, String> defaultSlots) {
        this.name = name;
        this.description = description;
        this.badgeCode = badgeCode;
        this.category = category;
        this.enabled = false;
        this.keybind = "None";
        this.delayMs = defaultDelayMs;
        this.slots = Collections.synchronizedMap(new LinkedHashMap<>(defaultSlots));
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getBadgeCode() {
        return badgeCode;
    }

    public MacroCategory getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getKeybind() {
        return keybind;
    }

    public void setKeybind(String keybind) {
        this.keybind = (keybind == null || keybind.isBlank()) ? "None" : keybind.trim();
    }

    public int getDelayMs() {
        return delayMs;
    }

    public void setDelayMs(int delayMs) {
        this.delayMs = Math.max(0, delayMs);
    }

    public Map<String, String> getSlots() {
        return slots;
    }

    public String getSlotValue(String slotName) {
        String direct = slots.get(slotName);
        if (direct != null) {
            return direct;
        }
        for (Map.Entry<String, String> entry : slots.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(slotName)) {
                return entry.getValue();
            }
        }
        return "";
    }

    public void setSlotValue(String slotName, String keyName) {
        slots.put(slotName, keyName == null ? "" : keyName.trim());
    }
}
