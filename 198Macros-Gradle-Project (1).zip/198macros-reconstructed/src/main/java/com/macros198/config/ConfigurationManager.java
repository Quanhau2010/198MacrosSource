package com.macros198.config;

import com.macros198.model.MacroCategory;
import com.macros198.model.ThemePalette;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Manages macro configuration state and local JSON persistence.
 *
 * <p>Reconstructed from {@code 0x1401142a0} ({@code saveConfig}), {@code 0x140114da0}
 * ({@code loadConfig}), {@code 0x14014bae0} (config map sync at {@code 0x14054f530}),
 * and {@code 0x14014f1e0} (default card initialization). Cloud-bound endpoints
 * ({@code /saveConfig}, {@code /getConfig}) and Code Virtualizer wrappers
 * ({@code 0x140178760}, {@code 0x140178de0}) have been completely removed in favor
 * of local JSON storage.
 */
public final class ConfigurationManager {
    private final Map<String, MacroConfiguration> macroConfigs = new LinkedHashMap<>();
    private final Path configFilePath;
    private volatile ThemePalette activeTheme = ThemePalette.DARK;
    private volatile String toggleUiKeybind = "None";

    public ConfigurationManager() {
        this(Paths.get(System.getProperty("user.home", "."), ".198macros", "config.json"));
    }

    public ConfigurationManager(Path configFilePath) {
        this.configFilePath = configFilePath;
        initializeDefaultCards();
    }

    /**
     * Populates all 14 macro cards with the exact defaults from {@code 0x14014f1e0}–{@code 0x140150a30}.
     */
    public void initializeDefaultCards() {
        macroConfigs.clear();

        // Category 1: Crystal Macros (0x14054f6f8)
        registerCard(
                "Hit Crystal",
                "Auto place obsidian and hit crystal",
                "HC",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Crystal Slot", "2", "Obsidian Slot", "3"));

        registerCard(
                "Single Anchor",
                "Auto place and explode an anchor",
                "SA",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Anchor Slot", "5", "Glowstone Slot", "6", "Totem/Explode Slot", "8"));

        registerCard(
                "Double Anchor",
                "Auto place and explode two anchors",
                "DA",
                MacroCategory.CRYSTAL,
                75,
                mapOf("Anchor Slot", "5", "Glowstone Slot", "6", "Totem/Explode Slot", "8"));

        registerCard(
                "Anchor Pearl",
                "Anchor and pearl right after to get low ground first",
                "AP",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Anchor Slot", "5", "Glowstone Slot", "6", "Pearl Slot", "8"));

        registerCard(
                "Slow Hit Crystal",
                "Hit Crystal with optimal timing",
                "SHC",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Crystal Slot", "2", "Obsidian Slot", "3"));

        registerCard(
                "Key Pearl",
                "Switches and throws pearl, then switches back",
                "KP",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Pearl Slot", "2", "Swap Back Slot", "3"));

        registerCard(
                "Inventory D-Hand",
                "Presses totem slot when opening inventory.\n ! Keybind this to your open inventory key. !",
                "IDH",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Totem Slot", "8"));

        registerCard(
                "Offhand Hotbar Totem",
                "Offhands your hotbar totem when pressed",
                "OHT",
                MacroCategory.CRYSTAL,
                50,
                mapOf("Totem Slot", "8", "Swap Hands Bind", "F"));

        registerCard(
                "Fast XP",
                "Automatically spams right click to exp faster",
                "FXP",
                MacroCategory.CRYSTAL,
                50,
                Collections.emptyMap());

        // Category 2: Mace Macros (0x14054f710)
        registerCard(
                "Stun Slam",
                "Auto break shields with mace",
                "SS",
                MacroCategory.MACE,
                80,
                mapOf("Axe slot", "8", "Mace Slot", "7"));

        registerCard(
                "Pearl Catch",
                "Automatically go up using a pearl and wind charge",
                "PC",
                MacroCategory.MACE,
                50,
                mapOf("Pearl slot", "4", "Wind Charge Slot", "2"));

        registerCard(
                "Elytra Swap",
                "Swaps to your elytra/chestplate slot and presses right click",
                "ES",
                MacroCategory.MACE,
                50,
                mapOf("Elytra/Chestplate Slot", "2"));

        registerCard(
                "Breach Swap",
                "Automatically swaps to mace when swinging with your sword",
                "BS",
                MacroCategory.MACE,
                50,
                mapOf("Mace Slot", "5", "Sword Slot", "1"));

        // Category 3: Sword Macros (0x14054f6c8)
        registerCard(
                "Auto Shield Breaker",
                "Automatically uses axe to break shields",
                "ASB",
                MacroCategory.SWORD,
                50,
                mapOf("Axe Slot", "8", "Sword Slot", "1"));
    }

    private void registerCard(
            String name,
            String description,
            String badge,
            MacroCategory category,
            int defaultDelayMs,
            Map<String, String> defaultSlots) {
        macroConfigs.put(
                name,
                new MacroConfiguration(name, description, badge, category, defaultDelayMs, defaultSlots));
    }

    public MacroConfiguration getMacroConfig(String macroName) {
        return macroConfigs.get(macroName);
    }

    public Collection<MacroConfiguration> getAllMacroConfigs() {
        return Collections.unmodifiableCollection(macroConfigs.values());
    }

    public ThemePalette getActiveTheme() {
        return activeTheme;
    }

    public void setActiveTheme(ThemePalette activeTheme) {
        if (activeTheme != null) {
            this.activeTheme = activeTheme;
        }
    }

    public String getToggleUiKeybind() {
        return toggleUiKeybind;
    }

    public void setToggleUiKeybind(String toggleUiKeybind) {
        this.toggleUiKeybind = (toggleUiKeybind == null || toggleUiKeybind.isBlank()) ? "None" : toggleUiKeybind.trim();
    }

    public Path getConfigFilePath() {
        return configFilePath;
    }

    /**
     * Serializes the configuration map using the exact JSON format constructed in {@code 0x1401142a0}:
     * {@code "MacroName": { "enabled": bool, "keybind": "...", "delay": int, "slots": { ... } }, "theme": int, "toggleUI": "..."}.
     */
    public String serializeToJson() {
        StringBuilder sb = new StringBuilder(2048);
        sb.append("{\n");
        for (MacroConfiguration card : macroConfigs.values()) {
            sb.append("  \"").append(escapeJson(card.getName())).append("\": {\n");
            sb.append("    \"enabled\": ").append(card.isEnabled()).append(",\n");
            sb.append("    \"keybind\": \"").append(escapeJson(card.getKeybind())).append("\",\n");
            sb.append("    \"delay\": ").append(card.getDelayMs()).append(",\n");
            sb.append("    \"slots\": {");
            Map<String, String> slots = card.getSlots();
            if (!slots.isEmpty()) {
                sb.append("\n");
                int idx = 0;
                for (Map.Entry<String, String> entry : slots.entrySet()) {
                    sb.append("      \"")
                            .append(escapeJson(entry.getKey()))
                            .append("\": \"")
                            .append(escapeJson(entry.getValue()))
                            .append("\"");
                    if (++idx < slots.size()) {
                        sb.append(",");
                    }
                    sb.append("\n");
                }
                sb.append("    }");
            } else {
                sb.append("}");
            }
            sb.append("\n  },\n");
        }
        sb.append("  \"theme\": ").append(activeTheme.getIndex()).append(",\n");
        sb.append("  \"toggleUI\": \"").append(escapeJson(toggleUiKeybind)).append("\"\n");
        sb.append("}\n");
        return sb.toString();
    }

    /**
     * Parses a JSON configuration string matching the schema of {@code 0x140114da0}.
     */
    public void loadFromJson(String json) {
        if (json == null || json.isBlank()) {
            return;
        }
        Matcher themeMatcher = Pattern.compile("\"theme\"\\s*:\\s*(\\d+)").matcher(json);
        if (themeMatcher.find()) {
            setActiveTheme(ThemePalette.fromIndex(Integer.parseInt(themeMatcher.group(1))));
        }

        Matcher toggleMatcher = Pattern.compile("\"toggleUI\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        if (toggleMatcher.find()) {
            setToggleUiKeybind(toggleMatcher.group(1));
        }

        for (MacroConfiguration card : macroConfigs.values()) {
            String quotedName = Pattern.quote("\"" + card.getName() + "\"");
            Matcher blockMatcher =
                    Pattern.compile(quotedName + "\\s*:\\s*\\{(.*?\\{[^{}]*\\}.*?)\\}", Pattern.DOTALL)
                            .matcher(json);
            if (!blockMatcher.find()) {
                continue;
            }
            String body = blockMatcher.group(1);

            Matcher enabledMatcher = Pattern.compile("\"enabled\"\\s*:\\s*(true|false)").matcher(body);
            if (enabledMatcher.find()) {
                card.setEnabled(Boolean.parseBoolean(enabledMatcher.group(1)));
            }

            Matcher keybindMatcher = Pattern.compile("\"keybind\"\\s*:\\s*\"([^\"]*)\"").matcher(body);
            if (keybindMatcher.find()) {
                card.setKeybind(keybindMatcher.group(1));
            }

            Matcher delayMatcher = Pattern.compile("\"delay\"\\s*:\\s*(\\d+)").matcher(body);
            if (delayMatcher.find()) {
                card.setDelayMs(Integer.parseInt(delayMatcher.group(1)));
            }

            Matcher slotsMatcher =
                    Pattern.compile("\"slots\"\\s*:\\s*\\{([^{}]*)\\}", Pattern.DOTALL).matcher(body);
            if (slotsMatcher.find()) {
                String slotsBody = slotsMatcher.group(1);
                Matcher kvMatcher =
                        Pattern.compile("\"([^\"]+)\"\\s*:\\s*\"([^\"]*)\"").matcher(slotsBody);
                while (kvMatcher.find()) {
                    card.setSlotValue(kvMatcher.group(1), kvMatcher.group(2));
                }
            }
        }
    }

    public void saveToFile() throws IOException {
        Path parent = configFilePath.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        Files.writeString(configFilePath, serializeToJson(), StandardCharsets.UTF_8);
    }

    public void loadFromFile() throws IOException {
        if (Files.exists(configFilePath)) {
            loadFromJson(Files.readString(configFilePath, StandardCharsets.UTF_8));
        }
    }

    private static String escapeJson(String input) {
        return input.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    private static Map<String, String> mapOf(String... keyValues) {
        Map<String, String> map = new LinkedHashMap<>();
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            map.put(keyValues[i], keyValues[i + 1]);
        }
        return map;
    }
}
