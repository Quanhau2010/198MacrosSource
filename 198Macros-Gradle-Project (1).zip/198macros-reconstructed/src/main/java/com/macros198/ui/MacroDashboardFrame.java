package com.macros198.ui;

import com.macros198.config.ConfigurationManager;
import com.macros198.config.MacroConfiguration;
import com.macros198.input.GlobalInputDispatcher;
import com.macros198.input.KeybindMapper;
import com.macros198.macro.AbstractMacro;
import com.macros198.macro.MacroRegistry;
import com.macros198.model.MacroCategory;
import com.macros198.model.ThemePalette;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * Reconstructed desktop GUI matching the Direct2D/DirectWrite interface of {@code 198macros.exe}
 * ({@code 0x1401561a0}–{@code 0x14015bf10}), with the login gate ({@code 0x1401594f0}) permanently
 * removed so the application opens directly into the macro dashboard.
 */
public final class MacroDashboardFrame extends JFrame {
    private static final String VERSION_TITLE = "198 Macros v1.4.0";

    private final ConfigurationManager configManager;
    private final MacroRegistry macroRegistry;
    private final GlobalInputDispatcher inputDispatcher;

    private MacroCategory selectedCategory = MacroCategory.CRYSTAL;
    private boolean showingSettingsTab = false;

    private final JPanel rootPanel = new JPanel(new BorderLayout());
    private final JPanel sidebarPanel = new JPanel();
    private final JPanel contentHeaderPanel = new JPanel(new BorderLayout());
    private final JPanel cardsContainerPanel = new JPanel();
    private JScrollPane scrollPane;

    public MacroDashboardFrame(
            ConfigurationManager configManager,
            MacroRegistry macroRegistry,
            GlobalInputDispatcher inputDispatcher) {
        super(VERSION_TITLE);
        this.configManager = configManager;
        this.macroRegistry = macroRegistry;
        this.inputDispatcher = inputDispatcher;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 680);
        setMinimumSize(new Dimension(860, 560));
        setLocationRelativeTo(null);

        this.inputDispatcher.setToggleUiCallback(() -> setVisible(!isVisible()));

        buildLayout();
        refreshThemeAndContent();
    }

    private void buildLayout() {
        rootPanel.setBorder(new EmptyBorder(0, 0, 0, 0));

        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setPreferredSize(new Dimension(220, 680));
        sidebarPanel.setBorder(new EmptyBorder(20, 16, 20, 16));

        JPanel mainArea = new JPanel(new BorderLayout());
        contentHeaderPanel.setBorder(new EmptyBorder(20, 24, 12, 24));
        mainArea.add(contentHeaderPanel, BorderLayout.NORTH);

        cardsContainerPanel.setLayout(new BoxLayout(cardsContainerPanel, BoxLayout.Y_AXIS));
        cardsContainerPanel.setBorder(new EmptyBorder(8, 24, 24, 24));

        scrollPane = new JScrollPane(cardsContainerPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainArea.add(scrollPane, BorderLayout.CENTER);

        rootPanel.add(sidebarPanel, BorderLayout.WEST);
        rootPanel.add(mainArea, BorderLayout.CENTER);
        setContentPane(rootPanel);
    }

    public void refreshThemeAndContent() {
        ThemePalette theme = configManager.getActiveTheme();

        rootPanel.setBackground(theme.getBackgroundColor());
        sidebarPanel.setBackground(theme.getCardColor());
        contentHeaderPanel.setBackground(theme.getBackgroundColor());
        cardsContainerPanel.setBackground(theme.getBackgroundColor());
        scrollPane.getViewport().setBackground(theme.getBackgroundColor());

        rebuildSidebar(theme);
        rebuildHeader(theme);
        rebuildCards(theme);

        revalidate();
        repaint();
    }

    private void rebuildSidebar(ThemePalette theme) {
        sidebarPanel.removeAll();

        JLabel brandTitle = new JLabel("198 Macros");
        brandTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        brandTitle.setForeground(theme.getAccentColor());
        brandTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebarPanel.add(brandTitle);

        JLabel versionLabel = new JLabel("v1.4.0 • Connected");
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        versionLabel.setForeground(theme.getTextColor().darker());
        versionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebarPanel.add(versionLabel);

        sidebarPanel.add(Box.createVerticalStrut(24));

        JLabel macrosSection = new JLabel("MACROS");
        macrosSection.setFont(new Font("Segoe UI", Font.BOLD, 11));
        macrosSection.setForeground(theme.getTextColor().darker());
        macrosSection.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebarPanel.add(macrosSection);
        sidebarPanel.add(Box.createVerticalStrut(8));

        for (MacroCategory category : MacroCategory.values()) {
            boolean active = !showingSettingsTab && selectedCategory == category;
            JButton tabBtn = createSidebarButton(category.getShortLabel(), active, theme);
            tabBtn.addActionListener(e -> {
                showingSettingsTab = false;
                selectedCategory = category;
                refreshThemeAndContent();
            });
            sidebarPanel.add(tabBtn);
            sidebarPanel.add(Box.createVerticalStrut(6));
        }

        sidebarPanel.add(Box.createVerticalStrut(18));

        JLabel otherSection = new JLabel("OTHER");
        otherSection.setFont(new Font("Segoe UI", Font.BOLD, 11));
        otherSection.setForeground(theme.getTextColor().darker());
        otherSection.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebarPanel.add(otherSection);
        sidebarPanel.add(Box.createVerticalStrut(8));

        JButton settingsBtn = createSidebarButton("Settings & Themes", showingSettingsTab, theme);
        settingsBtn.addActionListener(e -> {
            showingSettingsTab = true;
            refreshThemeAndContent();
        });
        sidebarPanel.add(settingsBtn);

        sidebarPanel.add(Box.createVerticalGlue());

        JButton saveBtn = createSidebarButton("Save Config", false, theme);
        saveBtn.addActionListener(e -> {
            try {
                configManager.saveToFile();
            } catch (IOException ignored) {
            }
        });
        sidebarPanel.add(saveBtn);
    }

    private JButton createSidebarButton(String text, boolean active, ThemePalette theme) {
        JButton button = new JButton(text);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(190, 38));
        button.setPreferredSize(new Dimension(190, 38));
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", active ? Font.BOLD : Font.PLAIN, 13));
        button.setBackground(active ? theme.getAccentColor() : theme.getBackgroundColor());
        button.setForeground(theme.getTextColor());
        button.setBorder(new EmptyBorder(8, 12, 8, 12));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        return button;
    }

    private void rebuildHeader(ThemePalette theme) {
        contentHeaderPanel.removeAll();
        JPanel titles = new JPanel(new GridLayout(2, 1, 0, 4));
        titles.setOpaque(false);

        String titleText = showingSettingsTab ? "Themes & Settings" : selectedCategory.getHeaderTitle();
        String subText =
                showingSettingsTab
                        ? "Customize the appearance of your interface"
                        : selectedCategory.getSubtitle();

        JLabel title = new JLabel(titleText);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(theme.getTextColor());

        JLabel subtitle = new JLabel(subText);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(theme.getTextColor().darker());

        titles.add(title);
        titles.add(subtitle);
        contentHeaderPanel.add(titles, BorderLayout.WEST);
    }

    private void rebuildCards(ThemePalette theme) {
        cardsContainerPanel.removeAll();

        if (showingSettingsTab) {
            cardsContainerPanel.add(buildSettingsPanel(theme));
            return;
        }

        for (MacroConfiguration card : configManager.getAllMacroConfigs()) {
            if (card.getCategory() == selectedCategory) {
                cardsContainerPanel.add(buildMacroCardPanel(card, theme));
                cardsContainerPanel.add(Box.createVerticalStrut(12));
            }
        }
    }

    private JPanel buildMacroCardPanel(MacroConfiguration card, ThemePalette theme) {
        JPanel panel = new JPanel(new BorderLayout(16, 12));
        panel.setBackground(theme.getCardColor());
        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(theme.getAccentColor().darker(), 1),
                        new EmptyBorder(14, 16, 14, 16)));
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 175));

        // Top row: [Badge] Name + Description on left, Enabled checkbox + Test button on right
        JPanel topRow = new JPanel(new BorderLayout(12, 0));
        topRow.setOpaque(false);

        JLabel badgeLabel = new JLabel(card.getBadgeCode(), SwingConstants.CENTER);
        badgeLabel.setPreferredSize(new Dimension(42, 42));
        badgeLabel.setOpaque(true);
        badgeLabel.setBackground(theme.getAccentColor());
        badgeLabel.setForeground(Color.WHITE);
        badgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        topRow.add(badgeLabel, BorderLayout.WEST);

        JPanel titleBlock = new JPanel(new GridLayout(2, 1, 0, 2));
        titleBlock.setOpaque(false);
        JLabel nameLabel = new JLabel(card.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nameLabel.setForeground(theme.getTextColor());
        JLabel descLabel = new JLabel(card.getDescription().replace("\n", " "));
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(theme.getTextColor().darker());
        titleBlock.add(nameLabel);
        titleBlock.add(descLabel);
        topRow.add(titleBlock, BorderLayout.CENTER);

        JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightControls.setOpaque(false);

        JCheckBox enabledBox = new JCheckBox("Enabled", card.isEnabled());
        enabledBox.setOpaque(false);
        enabledBox.setForeground(theme.getTextColor());
        enabledBox.setFont(new Font("Segoe UI", Font.BOLD, 12));
        enabledBox.addActionListener(e -> card.setEnabled(enabledBox.isSelected()));
        rightControls.add(enabledBox);

        JButton triggerNowBtn = new JButton("Run Macro");
        triggerNowBtn.setBackground(theme.getBackgroundColor());
        triggerNowBtn.setForeground(theme.getTextColor());
        triggerNowBtn.setFocusPainted(false);
        triggerNowBtn.addActionListener(e -> {
            AbstractMacro impl = macroRegistry.findByName(card.getName());
            if (impl != null) {
                int vk = KeybindMapper.toVirtualKeyCode(card.getKeybind());
                impl.onKeyPress(vk);
            }
        });
        rightControls.add(triggerNowBtn);

        topRow.add(rightControls, BorderLayout.EAST);
        panel.add(topRow, BorderLayout.NORTH);

        // Bottom row: Keybind button, Delay spinner, and Slot fields
        JPanel controlsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        controlsRow.setOpaque(false);

        JLabel keybindLbl = new JLabel("Keybind:");
        keybindLbl.setForeground(theme.getTextColor());
        controlsRow.add(keybindLbl);

        JButton keybindBtn = new JButton(card.getKeybind());
        keybindBtn.setBackground(theme.getBackgroundColor());
        keybindBtn.setForeground(theme.getAccentColor());
        keybindBtn.setFocusPainted(false);
        keybindBtn.addActionListener(e -> {
            keybindBtn.setText("Press key...");
            keybindBtn.addKeyListener(
                    new KeyAdapter() {
                        @Override
                        public void keyPressed(KeyEvent ke) {
                            String keyName =
                                    ke.getKeyCode() == KeyEvent.VK_ESCAPE
                                            ? "None"
                                            : KeybindMapper.toKeyName(ke.getKeyCode());
                            card.setKeybind(keyName);
                            keybindBtn.setText(card.getKeybind());
                            keybindBtn.removeKeyListener(this);
                        }
                    });
            keybindBtn.requestFocusInWindow();
        });
        controlsRow.add(keybindBtn);

        JLabel delayLbl = new JLabel("Delay (ms):");
        delayLbl.setForeground(theme.getTextColor());
        controlsRow.add(delayLbl);

        JSpinner delaySpinner =
                new JSpinner(new SpinnerNumberModel(card.getDelayMs(), 0, 1000, 5));
        delaySpinner.addChangeListener(e -> card.setDelayMs((Integer) delaySpinner.getValue()));
        controlsRow.add(delaySpinner);

        for (Map.Entry<String, String> slotEntry : card.getSlots().entrySet()) {
            String slotName = slotEntry.getKey();
            JLabel slotLbl = new JLabel(slotName + ":");
            slotLbl.setForeground(theme.getTextColor());
            controlsRow.add(slotLbl);

            JTextField slotField = new JTextField(slotEntry.getValue(), 3);
            slotField.addActionListener(e -> card.setSlotValue(slotName, slotField.getText()));
            controlsRow.add(slotField);
        }

        panel.add(controlsRow, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel buildSettingsPanel(ThemePalette theme) {
        JPanel settingsPanel = new JPanel();
        settingsPanel.setLayout(new BoxLayout(settingsPanel, BoxLayout.Y_AXIS));
        settingsPanel.setOpaque(false);

        JPanel themeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        themeRow.setBackground(theme.getCardColor());
        themeRow.setBorder(new EmptyBorder(12, 16, 12, 16));

        JLabel themeLbl = new JLabel("Active Theme Palette:");
        themeLbl.setForeground(theme.getTextColor());
        themeLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        themeRow.add(themeLbl);

        JComboBox<ThemePalette> themeCombo = new JComboBox<>(ThemePalette.values());
        themeCombo.setSelectedItem(configManager.getActiveTheme());
        themeCombo.addActionListener(e -> {
            ThemePalette selected = (ThemePalette) themeCombo.getSelectedItem();
            if (selected != null) {
                configManager.setActiveTheme(selected);
                refreshThemeAndContent();
            }
        });
        themeRow.add(themeCombo);

        JLabel toggleLbl = new JLabel("Toggle UI Keybind:");
        toggleLbl.setForeground(theme.getTextColor());
        toggleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        themeRow.add(toggleLbl);

        JTextField toggleField = new JTextField(configManager.getToggleUiKeybind(), 8);
        toggleField.addActionListener(e -> configManager.setToggleUiKeybind(toggleField.getText()));
        themeRow.add(toggleField);

        settingsPanel.add(themeRow);
        return settingsPanel;
    }
}
