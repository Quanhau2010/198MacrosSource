package com.macros198.model;

/**
 * Combat macro categories reconstructed from the three global vector tables in
 * {@code 0x14014f1e0} ({@code 0x14054f6f8}, {@code 0x14054f710}, {@code 0x14054f6c8})
 * and UTF-16LE sidebar labels at {@code 0x14050ee38}–{@code 0x14050f160}.
 */
public enum MacroCategory {
    CRYSTAL("Crystal", "Crystal Macros", "Configure your end crystal PVP automation", "crystal-icon"),
    MACE("Mace", "Mace Macros", "Configure your mace combat macros", "mace-icon"),
    SWORD("Sword", "Sword Macros", "Configure your sword combat macros", "sword-icon");

    private final String shortLabel;
    private final String headerTitle;
    private final String subtitle;
    private final String iconIdentifier;

    MacroCategory(String shortLabel, String headerTitle, String subtitle, String iconIdentifier) {
        this.shortLabel = shortLabel;
        this.headerTitle = headerTitle;
        this.subtitle = subtitle;
        this.iconIdentifier = iconIdentifier;
    }

    public String getShortLabel() {
        return shortLabel;
    }

    public String getHeaderTitle() {
        return headerTitle;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getIconIdentifier() {
        return iconIdentifier;
    }
}
