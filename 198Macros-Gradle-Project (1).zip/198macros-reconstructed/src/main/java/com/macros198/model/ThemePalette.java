package com.macros198.model;

import java.awt.Color;

/**
 * UI theme palettes reconstructed from {@code 0x14014d4c0} and UTF-16LE literals
 * at {@code 0x14050def8}–{@code 0x14050e2a0}.
 */
public enum ThemePalette {
    DARK(0, "Dark", "Classic dark theme", new Color(18, 18, 22), new Color(28, 28, 34), new Color(99, 102, 241), new Color(240, 240, 245)),
    DARK_BLUE(1, "Dark Blue", "Premium cyan accents", new Color(12, 19, 31), new Color(20, 30, 48), new Color(56, 189, 248), new Color(235, 245, 255)),
    DARK_PURPLE(2, "Dark Purple", "Royal violet accents", new Color(19, 14, 29), new Color(30, 22, 45), new Color(168, 85, 247), new Color(243, 235, 255)),
    DARK_GREEN(3, "Dark Green", "Matrix emerald vibes", new Color(11, 22, 17), new Color(18, 35, 27), new Color(16, 185, 129), new Color(230, 250, 240)),
    DARK_RED(4, "Dark Red", "Crimson blood accent", new Color(24, 12, 14), new Color(38, 19, 22), new Color(239, 68, 68), new Color(255, 235, 238)),
    MIDNIGHT(5, "Midnight", "Deep space darkness", new Color(8, 10, 18), new Color(15, 18, 30), new Color(96, 165, 250), new Color(226, 232, 240)),
    DARK_ORANGE(6, "Dark Orange", "Warm amber glow", new Color(24, 16, 11), new Color(38, 25, 17), new Color(249, 115, 22), new Color(255, 243, 230)),
    DARK_PINK(7, "Dark Pink", "Hot magenta vibes", new Color(24, 12, 20), new Color(38, 19, 32), new Color(236, 72, 153), new Color(253, 235, 245)),
    DRACULA(8, "Dracula", "Legendary vampire theme", new Color(40, 42, 54), new Color(68, 71, 90), new Color(189, 147, 249), new Color(248, 248, 242)),
    ARCTIC(9, "Arctic", "Pristine frozen white", new Color(241, 245, 249), new Color(255, 255, 255), new Color(14, 165, 233), new Color(15, 23, 42)),
    OBSIDIAN(10, "Obsidian", "Premium black & gold", new Color(10, 10, 12), new Color(20, 20, 24), new Color(234, 179, 8), new Color(245, 245, 240)),
    SLATE(11, "Slate", "Modern minimalist gray", new Color(15, 23, 42), new Color(30, 41, 59), new Color(148, 163, 184), new Color(241, 245, 249)),
    ESPRESSO(12, "Espresso", "Rich coffee warmth", new Color(23, 17, 14), new Color(36, 27, 22), new Color(217, 119, 6), new Color(245, 235, 224)),
    TOKYO_NIGHT(13, "Tokyo Night", "Neon city streets", new Color(26, 27, 38), new Color(36, 40, 59), new Color(122, 162, 247), new Color(192, 202, 245)),
    ABYSS(14, "Abyss", "Deep ocean depths", new Color(6, 16, 24), new Color(12, 28, 40), new Color(6, 182, 212), new Color(224, 242, 254));

    private final int index;
    private final String displayName;
    private final String description;
    private final Color backgroundColor;
    private final Color cardColor;
    private final Color accentColor;
    private final Color textColor;

    ThemePalette(
            int index,
            String displayName,
            String description,
            Color backgroundColor,
            Color cardColor,
            Color accentColor,
            Color textColor) {
        this.index = index;
        this.displayName = displayName;
        this.description = description;
        this.backgroundColor = backgroundColor;
        this.cardColor = cardColor;
        this.accentColor = accentColor;
        this.textColor = textColor;
    }

    public int getIndex() {
        return index;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public Color getBackgroundColor() {
        return backgroundColor;
    }

    public Color getCardColor() {
        return cardColor;
    }

    public Color getAccentColor() {
        return accentColor;
    }

    public Color getTextColor() {
        return textColor;
    }

    public static ThemePalette fromIndex(int index) {
        for (ThemePalette palette : values()) {
            if (palette.index == index) {
                return palette;
            }
        }
        return DARK;
    }
}
