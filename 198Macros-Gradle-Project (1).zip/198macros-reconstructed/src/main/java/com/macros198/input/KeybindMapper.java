package com.macros198.input;

import java.awt.event.KeyEvent;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Bidirectional mapper between human-readable keybind strings and Virtual Key codes.
 *
 * <p>Reconstructed directly from {@code 0x1401291c0} (string-to-VK resolver) and
 * the UTF-16LE key name tables at {@code 0x140506df0}–{@code 0x140506e80} and
 * {@code 0x14050f1c0}–{@code 0x14050f2f0}.
 */
public final class KeybindMapper {
    public static final int VK_NONE = -1;
    public static final int VK_LBUTTON = 0x01;
    public static final int VK_RBUTTON = 0x02;
    public static final int VK_MBUTTON = 0x04;
    public static final int VK_XBUTTON1 = 0x05; // MOUSE4
    public static final int VK_XBUTTON2 = 0x06; // MOUSE5

    private static final Map<String, Integer> NAME_TO_VK;
    private static final Map<Integer, String> VK_TO_NAME;

    static {
        Map<String, Integer> forward = new LinkedHashMap<>();
        Map<Integer, String> reverse = new LinkedHashMap<>();

        register(forward, reverse, "NONE", VK_NONE);
        register(forward, reverse, "MBUTTON", VK_MBUTTON);
        register(forward, reverse, "MIDDLE", VK_MBUTTON);
        register(forward, reverse, "MOUSE3", VK_MBUTTON);
        register(forward, reverse, "MOUSE4", VK_XBUTTON1);
        register(forward, reverse, "MOUSE5", VK_XBUTTON2);

        register(forward, reverse, "SPACE", KeyEvent.VK_SPACE);
        register(forward, reverse, "ENTER", KeyEvent.VK_ENTER);
        register(forward, reverse, "BACK", KeyEvent.VK_BACK_SPACE);
        register(forward, reverse, "ESC", KeyEvent.VK_ESCAPE);
        register(forward, reverse, "TAB", KeyEvent.VK_TAB);
        register(forward, reverse, "SHIFT", KeyEvent.VK_SHIFT);
        register(forward, reverse, "CTRL", KeyEvent.VK_CONTROL);
        register(forward, reverse, "ALT", KeyEvent.VK_ALT);
        register(forward, reverse, "CAPS", KeyEvent.VK_CAPS_LOCK);
        register(forward, reverse, "GRAVE", KeyEvent.VK_BACK_QUOTE);

        register(forward, reverse, "LEFT", KeyEvent.VK_LEFT);
        register(forward, reverse, "UP", KeyEvent.VK_UP);
        register(forward, reverse, "RIGHT", KeyEvent.VK_RIGHT);
        register(forward, reverse, "DOWN", KeyEvent.VK_DOWN);

        for (int i = 1; i <= 12; i++) {
            register(forward, reverse, "F" + i, KeyEvent.VK_F1 + (i - 1));
        }

        for (int i = 0; i <= 9; i++) {
            register(forward, reverse, "NUMPAD" + i, KeyEvent.VK_NUMPAD0 + i);
        }

        for (char c = '0'; c <= '9'; c++) {
            register(forward, reverse, String.valueOf(c), (int) c);
        }

        for (char c = 'A'; c <= 'Z'; c++) {
            register(forward, reverse, String.valueOf(c), (int) c);
        }

        NAME_TO_VK = Collections.unmodifiableMap(forward);
        VK_TO_NAME = Collections.unmodifiableMap(reverse);
    }

    private KeybindMapper() {}

    private static void register(Map<String, Integer> forward, Map<Integer, String> reverse, String name, int vk) {
        forward.put(name.toUpperCase(Locale.ROOT), vk);
        reverse.putIfAbsent(vk, name);
    }

    /**
     * Resolves a key name string (such as {@code "2"}, {@code "F"}, {@code "MOUSE4"}, {@code "NUMPAD1"})
     * into its integer Virtual Key code, matching {@code 0x1401291c0}.
     */
    public static int toVirtualKeyCode(String keyName) {
        if (keyName == null || keyName.isBlank()) {
            return VK_NONE;
        }
        String normalized = keyName.trim().toUpperCase(Locale.ROOT);
        if ("NONE".equals(normalized)) {
            return VK_NONE;
        }
        Integer mapped = NAME_TO_VK.get(normalized);
        if (mapped != null) {
            return mapped;
        }
        if (normalized.length() == 1) {
            return normalized.charAt(0);
        }
        return VK_NONE;
    }

    public static String toKeyName(int virtualKeyCode) {
        return VK_TO_NAME.getOrDefault(virtualKeyCode, "None");
    }
}
