package com.macros198.input;

import com.macros198.config.ConfigurationManager;
import com.macros198.config.MacroConfiguration;
import com.macros198.macro.AbstractMacro;
import com.macros198.macro.MacroRegistry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Global keyboard and mouse hook event dispatcher.
 *
 * <p>Reconstructed from:
 * <ul>
 *   <li>{@code 0x14012b3c0}: {@code LowLevelKeyboardProc} ({@code WH_KEYBOARD_LL = 13})</li>
 *   <li>{@code 0x14012b320}: {@code LowLevelMouseProc} ({@code WH_MOUSE_LL = 14})</li>
 *   <li>{@code 0x14012a290}: Key-press macro lookup & detached worker thread spawner ({@code 0x14012bd40})</li>
 *   <li>{@code 0x14012acc0}: Mouse-click macro lookup & detached worker thread spawner ({@code 0x14012bda0})</li>
 * </ul>
 */
public final class GlobalInputDispatcher implements AutoCloseable {
    private final ConfigurationManager configManager;
    private final MacroRegistry macroRegistry;
    private final InputSimulationController inputController;
    private final Set<Integer> activeDebouncedKeys = ConcurrentHashMap.newKeySet();
    private final ExecutorService macroWorkerPool;
    private volatile Consumer<Integer> keybindCaptureCallback;
    private volatile Runnable toggleUiCallback;

    public GlobalInputDispatcher(
            ConfigurationManager configManager,
            MacroRegistry macroRegistry,
            InputSimulationController inputController) {
        this.configManager = configManager;
        this.macroRegistry = macroRegistry;
        this.inputController = inputController;
        this.macroWorkerPool = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "198Macros-Worker");
            t.setDaemon(true);
            return t;
        });
    }

    public void startNativeHooks() {
        inputController.getWin32Bridge().startGlobalHooks(this);
    }

    public void setKeybindCaptureCallback(Consumer<Integer> callback) {
        this.keybindCaptureCallback = callback;
    }

    public void setToggleUiCallback(Runnable callback) {
        this.toggleUiCallback = callback;
    }

    /**
     * Handles a key-down or side/middle mouse-button-down event (matching {@code 0x14012b3c0} & {@code 0x14012a290}).
     */
    public void onKeyDown(int virtualKeyCode) {
        if (virtualKeyCode <= 0) {
            return;
        }
        inputController.markKeyHeld(virtualKeyCode, true);

        // Key-repeat debounce check (reconstructed from the FNV-1a unordered_set at 0x14054f658 in 0x14012ba30)
        if (!activeDebouncedKeys.add(virtualKeyCode)) {
            return;
        }

        // Check if UI is currently capturing a new keybind (0x14054f529)
        Consumer<Integer> capture = this.keybindCaptureCallback;
        if (capture != null) {
            this.keybindCaptureCallback = null;
            capture.accept(virtualKeyCode);
            return;
        }

        // Check toggleUI hotkey (0x14012ab06..0x14012aba1)
        int toggleVk = KeybindMapper.toVirtualKeyCode(configManager.getToggleUiKeybind());
        if (toggleVk != KeybindMapper.VK_NONE && toggleVk == virtualKeyCode) {
            Runnable toggle = this.toggleUiCallback;
            if (toggle != null) {
                toggle.run();
            }
        }

        // Dispatch matching enabled macros on detached worker threads (0x14012a9a5..0x14012aa28)
        for (AbstractMacro macro : macroRegistry.getMacros()) {
            MacroConfiguration cfg = macro.getConfiguration();
            if (cfg == null || !cfg.isEnabled()) {
                continue;
            }
            int boundVk = KeybindMapper.toVirtualKeyCode(cfg.getKeybind());
            if (boundVk != KeybindMapper.VK_NONE && boundVk == virtualKeyCode) {
                macroWorkerPool.submit(() -> macro.onKeyPress(virtualKeyCode));
            }
        }
    }

    /**
     * Handles a key-up event, clearing the debounce table entry (matching {@code 0x14012b466}–{@code 0x14012b575}).
     */
    public void onKeyUp(int virtualKeyCode) {
        inputController.markKeyHeld(virtualKeyCode, false);
        activeDebouncedKeys.remove(virtualKeyCode);
    }

    /**
     * Handles a primary/secondary mouse button press ({@code 1} = Left Click, {@code 2} = Right Click),
     * replicating {@code 0x14012b36c}–{@code 0x14012b38f} and {@code 0x14012acc0}–{@code 0x14012b189}:
     * every enabled macro receives {@code macro.onMouseClick(mouseButton)} on a worker thread
     * (used by {@code BreachSwap} at {@code 0x14012d400} to swap to Mace on left-click).
     */
    public void onMouseButtonDown(int mouseButton) {
        if (keybindCaptureCallback != null) {
            return;
        }
        for (AbstractMacro macro : macroRegistry.getMacros()) {
            MacroConfiguration cfg = macro.getConfiguration();
            if (cfg != null && cfg.isEnabled()) {
                macroWorkerPool.submit(() -> macro.onMouseClick(mouseButton));
            }
        }
    }

    @Override
    public void close() {
        inputController.getWin32Bridge().close();
        macroWorkerPool.shutdownNow();
    }
}
