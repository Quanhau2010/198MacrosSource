package com.macros198.input;

import java.awt.AWTException;
import java.awt.GraphicsEnvironment;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe keyboard and mouse input synthesis controller.
 *
 * <p>On Windows, delegates directly to {@link Win32NativeBridge} ({@code USER32.dll!SendInput}
 * and {@code USER32.dll!GetAsyncKeyState}), replicating {@code 0x14017cb90}, {@code 0x14017ccc0},
 * and {@code 0x1403e9810} 100% natively. On non-Windows platforms, falls back to {@link Robot}.
 */
public final class InputSimulationController {
    private final ReentrantLock inputMutex = new ReentrantLock();
    private final Set<Integer> currentlyHeldKeys = ConcurrentHashMap.newKeySet();
    private final List<String> recordedEventLog = Collections.synchronizedList(new ArrayList<>());
    private final Win32NativeBridge win32Bridge = new Win32NativeBridge();
    private final Robot robot;
    private volatile boolean dryRunMode;

    public InputSimulationController() {
        Robot initializedRobot = null;
        if (!GraphicsEnvironment.isHeadless()) {
            try {
                initializedRobot = new Robot();
                initializedRobot.setAutoDelay(0);
            } catch (AWTException ignored) {
                initializedRobot = null;
            }
        }
        this.robot = initializedRobot;
        this.dryRunMode = (initializedRobot == null && !Win32NativeBridge.isWindowsPlatform());
    }

    public Win32NativeBridge getWin32Bridge() {
        return win32Bridge;
    }

    public void setDryRunMode(boolean dryRunMode) {
        this.dryRunMode = dryRunMode;
    }

    public boolean isDryRunMode() {
        return dryRunMode;
    }

    /**
     * Simulates an atomic key/button press-and-release event, matching {@code 0x14017cb90}.
     */
    public void pressKey(int virtualKeyCode) {
        if (virtualKeyCode <= 0) {
            return;
        }
        inputMutex.lock();
        try {
            recordedEventLog.add("KEY_PRESS:" + KeybindMapper.toKeyName(virtualKeyCode));
            if (dryRunMode) {
                return;
            }
            if (Win32NativeBridge.isWindowsPlatform() && win32Bridge.sendKeyOrMouseButtonPress(virtualKeyCode)) {
                return;
            }
            if (robot == null) {
                return;
            }
            if (virtualKeyCode == KeybindMapper.VK_MBUTTON) {
                robot.mousePress(InputEvent.BUTTON2_DOWN_MASK);
                robot.mouseRelease(InputEvent.BUTTON2_DOWN_MASK);
            } else if (virtualKeyCode == KeybindMapper.VK_XBUTTON1) {
                int mask = InputEvent.getMaskForButton(4);
                robot.mousePress(mask);
                robot.mouseRelease(mask);
            } else if (virtualKeyCode == KeybindMapper.VK_XBUTTON2) {
                int mask = InputEvent.getMaskForButton(5);
                robot.mousePress(mask);
                robot.mouseRelease(mask);
            } else {
                robot.keyPress(virtualKeyCode);
                robot.keyRelease(virtualKeyCode);
            }
        } catch (IllegalArgumentException ignored) {
        } finally {
            inputMutex.unlock();
        }
    }

    /**
     * Simulates an atomic mouse button click ({@code "left"}, {@code "middle"}, or {@code "right"}),
     * matching {@code 0x14017ccc0}.
     */
    public void clickMouse(String buttonName) {
        if (buttonName == null || buttonName.isEmpty()) {
            return;
        }
        String normalized = buttonName.toLowerCase(Locale.ROOT).trim();
        inputMutex.lock();
        try {
            recordedEventLog.add("MOUSE_CLICK:" + normalized);
            if (dryRunMode) {
                return;
            }
            if (Win32NativeBridge.isWindowsPlatform() && win32Bridge.sendMouseClick(normalized)) {
                return;
            }
            if (robot == null) {
                return;
            }
            final int mask;
            if ("left".equals(normalized)) {
                mask = InputEvent.BUTTON1_DOWN_MASK;
            } else if ("middle".equals(normalized)) {
                mask = InputEvent.BUTTON2_DOWN_MASK;
            } else if ("right".equals(normalized)) {
                mask = InputEvent.BUTTON3_DOWN_MASK;
            } else {
                return;
            }
            robot.mousePress(mask);
            robot.mouseRelease(mask);
        } finally {
            inputMutex.unlock();
        }
    }

    /**
     * Sleeps for {@code milliseconds} if strictly positive, matching {@code KERNEL32!Sleep} ({@code 0x1403e9410}).
     */
    public void sleepMillis(int milliseconds) {
        if (milliseconds <= 0) {
            return;
        }
        recordedEventLog.add("SLEEP:" + milliseconds);
        if (dryRunMode) {
            return;
        }
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Checks whether the trigger key is currently held down, matching {@code USER32!GetAsyncKeyState(vk) < 0}
     * ({@code 0x1403e9810}).
     */
    public boolean isKeyHeldDown(int virtualKeyCode) {
        if (!dryRunMode && Win32NativeBridge.isWindowsPlatform()) {
            return win32Bridge.isKeyPhysicallyDown(virtualKeyCode)
                    || currentlyHeldKeys.contains(virtualKeyCode);
        }
        return currentlyHeldKeys.contains(virtualKeyCode);
    }

    public void markKeyHeld(int virtualKeyCode, boolean held) {
        if (held) {
            currentlyHeldKeys.add(virtualKeyCode);
        } else {
            currentlyHeldKeys.remove(virtualKeyCode);
        }
    }

    public List<String> getRecordedEventLog() {
        return new ArrayList<>(recordedEventLog);
    }

    public void clearRecordedEventLog() {
        recordedEventLog.clear();
    }
}
