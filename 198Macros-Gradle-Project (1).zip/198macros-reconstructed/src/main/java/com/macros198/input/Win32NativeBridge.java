package com.macros198.input;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.platform.win32.BaseTSD.ULONG_PTR;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef.DWORD;
import com.sun.jna.platform.win32.WinDef.HMODULE;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinDef.LONG;
import com.sun.jna.platform.win32.WinDef.LRESULT;
import com.sun.jna.platform.win32.WinDef.WORD;
import com.sun.jna.platform.win32.WinDef.WPARAM;
import com.sun.jna.platform.win32.WinUser;
import com.sun.jna.platform.win32.WinUser.HHOOK;
import com.sun.jna.platform.win32.WinUser.HOOKPROC;
import com.sun.jna.platform.win32.WinUser.INPUT;
import com.sun.jna.platform.win32.WinUser.KBDLLHOOKSTRUCT;
import com.sun.jna.platform.win32.WinUser.LowLevelKeyboardProc;
import com.sun.jna.platform.win32.WinUser.MSG;
import com.sun.jna.win32.W32APIOptions;
import java.util.List;
import java.util.Locale;

/**
 * Direct Win32 Native API bridge via JNA that replicates the exact {@code USER32.dll}
 * calls from {@code 198macros.exe}:
 * <ul>
 *   <li>{@code 0x14015c7df}: {@code SetWindowsHookExW(WH_KEYBOARD_LL = 13, LowLevelKeyboardProc, hInstance, 0)}</li>
 *   <li>{@code 0x14015c808}: {@code SetWindowsHookExW(WH_MOUSE_LL = 14, LowLevelMouseProc, hInstance, 0)}</li>
 *   <li>{@code 0x14012b3c0}: {@code LowLevelKeyboardProc} handling {@code WM_KEYDOWN (0x100)},
 *       {@code WM_SYSKEYDOWN (0x104)}, {@code WM_KEYUP (0x101)}, {@code WM_SYSKEYUP (0x105)}</li>
 *   <li>{@code 0x14012b320}: {@code LowLevelMouseProc} handling {@code WM_LBUTTONDOWN (0x201)},
 *       {@code WM_RBUTTONDOWN (0x204)}, {@code WM_MBUTTONDOWN (0x207)}, {@code WM_XBUTTONDOWN (0x20B)}</li>
 *   <li>{@code 0x14017cb90} & {@code 0x14017ccc0}: {@code SendInput(2, inputs, sizeof(INPUT))}</li>
 *   <li>{@code 0x1403e9810}: {@code GetAsyncKeyState(vkCode) < 0}</li>
 * </ul>
 */
public final class Win32NativeBridge implements AutoCloseable {
    private static final boolean IS_WINDOWS =
            System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

    public static final int WH_KEYBOARD_LL = 13; // 0x0D at 0x14015c7da
    public static final int WH_MOUSE_LL = 14;    // 0x0E at 0x14015c803

    public static final int WM_KEYDOWN = 0x0100;
    public static final int WM_KEYUP = 0x0101;
    public static final int WM_SYSKEYDOWN = 0x0104;
    public static final int WM_SYSKEYUP = 0x0105;

    public static final int WM_LBUTTONDOWN = 0x0201;
    public static final int WM_RBUTTONDOWN = 0x0204;
    public static final int WM_MBUTTONDOWN = 0x0207;
    public static final int WM_MBUTTONUP = 0x0208;
    public static final int WM_XBUTTONDOWN = 0x020B;
    public static final int WM_XBUTTONUP = 0x020C;

    public static final int LLKHF_INJECTED = 0x00000010;
    public static final int LLMHF_INJECTED = 0x00000001;

    public static final int MOUSEEVENTF_LEFTDOWN = 0x0002;
    public static final int MOUSEEVENTF_LEFTUP = 0x0004;
    public static final int MOUSEEVENTF_RIGHTDOWN = 0x0008;
    public static final int MOUSEEVENTF_RIGHTUP = 0x0010;
    public static final int MOUSEEVENTF_MIDDLEDOWN = 0x0020;
    public static final int MOUSEEVENTF_MIDDLEUP = 0x0040;
    public static final int MOUSEEVENTF_XDOWN = 0x0080;
    public static final int MOUSEEVENTF_XUP = 0x0100;
    public static final int KEYEVENTF_KEYUP = 0x0002;

    @Structure.FieldOrder({"ptX", "ptY", "mouseData", "flags", "time", "dwExtraInfo"})
    public static class MSLLHOOKSTRUCT extends Structure {
        public LONG ptX;
        public LONG ptY;
        public int mouseData;
        public int flags;
        public int time;
        public ULONG_PTR dwExtraInfo;
    }

    public interface LowLevelMouseProc extends HOOKPROC {
        LRESULT callback(int nCode, WPARAM wParam, MSLLHOOKSTRUCT lParam);
    }

    private HHOOK keyboardHookHandle;
    private HHOOK mouseHookHandle;
    private Thread hookMessagePumpThread;
    private volatile boolean running;

    // Keep strong references to JNA callbacks so GC never collects them while hooked
    private LowLevelKeyboardProc keyboardHookCallback;
    private LowLevelMouseProc mouseHookCallback;

    public static boolean isWindowsPlatform() {
        return IS_WINDOWS;
    }

    /**
     * Checks {@code USER32.dll!GetAsyncKeyState(vkCode) < 0} (high bit {@code 0x8000} set),
     * matching {@code call QWORD PTR [0x1403e9810]; test ax, ax; js ...}.
     */
    public boolean isKeyPhysicallyDown(int virtualKeyCode) {
        if (!IS_WINDOWS || virtualKeyCode <= 0) {
            return false;
        }
        short state = User32.INSTANCE.GetAsyncKeyState(virtualKeyCode);
        return (state & 0x8000) != 0;
    }

    /**
     * Sends a 2-element {@code INPUT[2]} array via {@code USER32.dll!SendInput},
     * replicating {@code 0x14017cb90} byte-for-byte.
     */
    public boolean sendKeyOrMouseButtonPress(int virtualKeyCode) {
        if (!IS_WINDOWS || virtualKeyCode <= 0) {
            return false;
        }
        INPUT[] inputs = (INPUT[]) new INPUT().toArray(2);
        if (virtualKeyCode == KeybindMapper.VK_MBUTTON) {
            // 0x14017cbea..0x14017cbff: VK_MBUTTON (4) -> MOUSEEVENTF_MIDDLEDOWN (0x20) / MIDDLEUP (0x40)
            configureMouseInput(inputs[0], MOUSEEVENTF_MIDDLEDOWN, 0);
            configureMouseInput(inputs[1], MOUSEEVENTF_MIDDLEUP, 0);
        } else if (virtualKeyCode == KeybindMapper.VK_XBUTTON1 || virtualKeyCode == KeybindMapper.VK_XBUTTON2) {
            // 0x14017cc01..0x14017cc57: VK_XBUTTON1 (5) / VK_XBUTTON2 (6) -> XDOWN (0x80) / XUP (0x100)
            int xButtonData = (virtualKeyCode == KeybindMapper.VK_XBUTTON1) ? 1 : 2;
            configureMouseInput(inputs[0], MOUSEEVENTF_XDOWN, xButtonData);
            configureMouseInput(inputs[1], MOUSEEVENTF_XUP, xButtonData);
        } else {
            // 0x14017cc09..0x14017cc33: INPUT_KEYBOARD (1), wVk = virtualKeyCode, down (0) then KEYEVENTF_KEYUP (2)
            inputs[0].type = new DWORD(INPUT.INPUT_KEYBOARD);
            inputs[0].input.setType("ki");
            inputs[0].input.ki.wVk = new WORD(virtualKeyCode);
            inputs[0].input.ki.dwFlags = new DWORD(0);

            inputs[1].type = new DWORD(INPUT.INPUT_KEYBOARD);
            inputs[1].input.setType("ki");
            inputs[1].input.ki.wVk = new WORD(virtualKeyCode);
            inputs[1].input.ki.dwFlags = new DWORD(KEYEVENTF_KEYUP);
        }
        DWORD sent = User32.INSTANCE.SendInput(new DWORD(2), inputs, inputs[0].size());
        return sent.intValue() == 2;
    }

    /**
     * Sends a 2-element mouse click {@code INPUT[2]} array via {@code USER32.dll!SendInput},
     * replicating {@code 0x14017ccc0} byte-for-byte.
     */
    public boolean sendMouseClick(String buttonName) {
        if (!IS_WINDOWS || buttonName == null) {
            return false;
        }
        String norm = buttonName.toLowerCase(Locale.ROOT).trim();
        final int downFlag;
        final int upFlag;
        if ("left".equals(norm)) {
            downFlag = MOUSEEVENTF_LEFTDOWN;
            upFlag = MOUSEEVENTF_LEFTUP;
        } else if ("middle".equals(norm)) {
            downFlag = MOUSEEVENTF_MIDDLEDOWN;
            upFlag = MOUSEEVENTF_MIDDLEUP;
        } else if ("right".equals(norm)) {
            downFlag = MOUSEEVENTF_RIGHTDOWN;
            upFlag = MOUSEEVENTF_RIGHTUP;
        } else {
            return false;
        }

        INPUT[] inputs = (INPUT[]) new INPUT().toArray(2);
        configureMouseInput(inputs[0], downFlag, 0);
        configureMouseInput(inputs[1], upFlag, 0);
        DWORD sent = User32.INSTANCE.SendInput(new DWORD(2), inputs, inputs[0].size());
        return sent.intValue() == 2;
    }

    private static void configureMouseInput(INPUT input, int flags, int mouseData) {
        input.type = new DWORD(INPUT.INPUT_MOUSE);
        input.input.setType("mi");
        input.input.mi.dwFlags = new DWORD(flags);
        input.input.mi.mouseData = new DWORD(mouseData);
    }

    /**
     * Installs the global {@code WH_KEYBOARD_LL (13)} and {@code WH_MOUSE_LL (14)} hooks
     * on a dedicated Win32 message-pump thread, replicating {@code 0x14015c7c3}–{@code 0x14015c830}.
     */
    public void startGlobalHooks(GlobalInputDispatcher dispatcher) {
        if (!IS_WINDOWS || running) {
            return;
        }
        running = true;
        hookMessagePumpThread =
                new Thread(
                        () -> runWin32HookPump(dispatcher),
                        "198Macros-Win32HookPump");
        hookMessagePumpThread.setDaemon(true);
        hookMessagePumpThread.start();
    }

    private void runWin32HookPump(GlobalInputDispatcher dispatcher) {
        HMODULE hMod = Kernel32.INSTANCE.GetModuleHandle(null);

        // Replicates LowLevelKeyboardProc at 0x14012b3c0
        keyboardHookCallback =
                (int nCode, WPARAM wParam, KBDLLHOOKSTRUCT info) -> {
                    if (nCode == WinUser.HC_ACTION && info != null) {
                        // Ignore synthetic inputs injected by our own SendInput calls
                        if ((info.flags & LLKHF_INJECTED) == 0) {
                            int msg = wParam.intValue();
                            int vkCode = info.vkCode;
                            // (wParam - 0x100) & ~4 == 0 -> WM_KEYDOWN (0x100) or WM_SYSKEYDOWN (0x104)
                            if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
                                dispatcher.onKeyDown(vkCode);
                            } else if (msg == WM_KEYUP || msg == WM_SYSKEYUP) {
                                dispatcher.onKeyUp(vkCode);
                            }
                        }
                    }
                    return User32.INSTANCE.CallNextHookEx(
                            keyboardHookHandle, nCode, wParam, new WinDefLParam(info.getPointer()));
                };

        // Replicates LowLevelMouseProc at 0x14012b320
        mouseHookCallback =
                (int nCode, WPARAM wParam, MSLLHOOKSTRUCT info) -> {
                    if (nCode == WinUser.HC_ACTION && info != null) {
                        if ((info.flags & LLMHF_INJECTED) == 0) {
                            int msg = wParam.intValue();
                            if (msg == WM_XBUTTONDOWN) {
                                int xBtn = (info.mouseData >>> 16) == 1
                                        ? KeybindMapper.VK_XBUTTON1
                                        : KeybindMapper.VK_XBUTTON2;
                                dispatcher.onKeyDown(xBtn);
                            } else if (msg == WM_XBUTTONUP) {
                                int xBtn = (info.mouseData >>> 16) == 1
                                        ? KeybindMapper.VK_XBUTTON1
                                        : KeybindMapper.VK_XBUTTON2;
                                dispatcher.onKeyUp(xBtn);
                            } else if (msg == WM_MBUTTONDOWN) {
                                dispatcher.onKeyDown(KeybindMapper.VK_MBUTTON);
                            } else if (msg == WM_MBUTTONUP) {
                                dispatcher.onKeyUp(KeybindMapper.VK_MBUTTON);
                            } else if (msg == WM_LBUTTONDOWN) {
                                dispatcher.onMouseButtonDown(1);
                            } else if (msg == WM_RBUTTONDOWN) {
                                dispatcher.onMouseButtonDown(2);
                            }
                        }
                    }
                    return User32.INSTANCE.CallNextHookEx(
                            mouseHookHandle, nCode, wParam, new WinDefLParam(info.getPointer()));
                };

        keyboardHookHandle =
                User32.INSTANCE.SetWindowsHookEx(WH_KEYBOARD_LL, keyboardHookCallback, hMod, 0);
        mouseHookHandle =
                User32.INSTANCE.SetWindowsHookEx(WH_MOUSE_LL, mouseHookCallback, hMod, 0);

        MSG msg = new MSG();
        while (running && User32.INSTANCE.GetMessage(msg, null, 0, 0) > 0) {
            User32.INSTANCE.TranslateMessage(msg);
            User32.INSTANCE.DispatchMessage(msg);
        }
    }

    private static final class WinDefLParam extends com.sun.jna.platform.win32.WinDef.LPARAM {
        WinDefLParam(Pointer p) {
            super(Pointer.nativeValue(p));
        }
    }

    @Override
    public void close() {
        running = false;
        if (IS_WINDOWS) {
            if (keyboardHookHandle != null) {
                User32.INSTANCE.UnhookWindowsHookEx(keyboardHookHandle);
                keyboardHookHandle = null;
            }
            if (mouseHookHandle != null) {
                User32.INSTANCE.UnhookWindowsHookEx(mouseHookHandle);
                mouseHookHandle = null;
            }
        }
    }
}
