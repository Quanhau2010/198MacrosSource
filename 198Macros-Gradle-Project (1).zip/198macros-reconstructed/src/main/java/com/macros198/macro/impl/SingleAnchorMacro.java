package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class SingleAnchor} (RTTI {@code 0x14054aa88}, vtable {@code 0x140507218},
 * {@code execute} at {@code 0x14012ef80}).
 *
 * <p>Exact execution sequence in {@code 0x14012ef80}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Anchor Slot"} ({@code r14d}),
 *       {@code "Glowstone Slot"} ({@code esi}), and {@code "Totem/Explode Slot"} ({@code edi}).</li>
 *   <li>Press {@code anchorSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code glowstoneSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code totemExplodeSlot}, right-click.</li>
 * </ol>
 */
public final class SingleAnchorMacro extends AbstractMacro {
    public SingleAnchorMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Single Anchor", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int anchorSlotKey = getSlotVirtualKeyCode("Anchor Slot");
        int glowstoneSlotKey = getSlotVirtualKeyCode("Glowstone Slot");
        int totemExplodeSlotKey = getSlotVirtualKeyCode("Totem/Explode Slot");

        inputController.pressKey(anchorSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(glowstoneSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(totemExplodeSlotKey);
        inputController.clickMouse("right");
    }
}
