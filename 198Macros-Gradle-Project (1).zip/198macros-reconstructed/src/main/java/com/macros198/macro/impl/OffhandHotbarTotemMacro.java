package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class OffhandHotbarTotem} (RTTI {@code 0x14054aa30}, vtable {@code 0x140507190},
 * {@code execute} at {@code 0x14012e770}).
 *
 * <p>Exact execution sequence in {@code 0x14012e770}:
 * <ol>
 *   <li>Read {@code delay} ({@code esi}), {@code "Totem Slot"} ({@code edi}), and {@code "Swap Hands Bind"} ({@code ebx}).</li>
 *   <li>Press {@code totemSlot}.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code swapHandsBind} (default {@code F}) to move the totem into the offhand slot.</li>
 * </ol>
 */
public final class OffhandHotbarTotemMacro extends AbstractMacro {
    public OffhandHotbarTotemMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Offhand Hotbar Totem", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int totemSlotKey = getSlotVirtualKeyCode("Totem Slot");
        int swapHandsKey = getSlotVirtualKeyCode("Swap Hands Bind");

        inputController.pressKey(totemSlotKey);
        inputController.sleepMillis(delayMs);
        inputController.pressKey(swapHandsKey);
    }
}
