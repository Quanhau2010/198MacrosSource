package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class AutoShieldBreaker} (RTTI {@code 0x14054a928}, vtable {@code 0x140506fc8},
 * {@code execute} at {@code 0x14012d010}).
 *
 * <p>Note: In {@code 0x14012d0c6}, the string {@code "Axe Slot"} is constructed on the stack via
 * {@code movabs rax, 0x746f6c5320657841}, and {@code "left"} is constructed via
 * {@code mov DWORD PTR [rbp-0x30], 0x7466656c} at {@code 0x14012d294}.
 *
 * <p>Exact execution sequence in {@code 0x14012d010}:
 * <ol>
 *   <li>Read {@code delay} ({@code r14d}), {@code "Axe Slot"} ({@code edi}), and {@code "Sword Slot"} ({@code ebx}).</li>
 *   <li>Press {@code axeSlot} and left-click to disable the opponent's shield.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code swordSlot} to swap back to the primary weapon.</li>
 * </ol>
 */
public final class AutoShieldBreakerMacro extends AbstractMacro {
    public AutoShieldBreakerMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Auto Shield Breaker", MacroCategory.SWORD, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int axeSlotKey = getSlotVirtualKeyCode("Axe Slot");
        int swordSlotKey = getSlotVirtualKeyCode("Sword Slot");

        inputController.pressKey(axeSlotKey);
        inputController.clickMouse("left");
        inputController.sleepMillis(delayMs);
        inputController.pressKey(swordSlotKey);
    }
}
