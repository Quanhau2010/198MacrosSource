package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class KeyPearl} (RTTI {@code 0x14054aa10}, vtable {@code 0x140507148},
 * {@code execute} at {@code 0x14012e360}).
 *
 * <p>Exact execution sequence in {@code 0x14012e360}:
 * <ol>
 *   <li>Read {@code delay} ({@code r14d}), {@code "Pearl Slot"} ({@code edi}), and {@code "Swap Back Slot"} ({@code ebx}).</li>
 *   <li>Press {@code pearlSlot} and right-click to throw the Ender Pearl.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code swapBackSlot} to return to the primary hotbar slot.</li>
 * </ol>
 */
public final class KeyPearlMacro extends AbstractMacro {
    public KeyPearlMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Key Pearl", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int pearlSlotKey = getSlotVirtualKeyCode("Pearl Slot");
        int swapBackSlotKey = getSlotVirtualKeyCode("Swap Back Slot");

        inputController.pressKey(pearlSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);
        inputController.pressKey(swapBackSlotKey);
    }
}
