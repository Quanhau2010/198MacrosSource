package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class SlowHitCrystal} (RTTI {@code 0x14054aab0}, vtable {@code 0x140507270},
 * {@code execute} at {@code 0x14012f5e0}).
 *
 * <p>Exact execution sequence in {@code 0x14012f5e0}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Obsidian Slot"} ({@code edi}), and {@code "Crystal Slot"} ({@code esi}).</li>
 *   <li>Press {@code obsidianSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code crystalSlot}, right-click, sleep {@code 100} ms ({@code 0x64} at {@code 0x14012f94e}), left-click.</li>
 *   <li>While {@code GetAsyncKeyState(triggerKeyCode) < 0} ({@code 0x14012f9c0} / {@code 0x14012faae}):
 *     <ul>
 *       <li>Right-click (place crystal), sleep {@code 200} ms ({@code 0xc8} at {@code 0x14012fa38}).</li>
 *       <li>Left-click (break crystal), sleep {@code delay} ms.</li>
 *     </ul>
 *   </li>
 * </ol>
 */
public final class SlowHitCrystalMacro extends AbstractMacro {
    private static final int INITIAL_CRYSTAL_BREAK_DELAY_MS = 100; // 0x64 at 0x14012f94e
    private static final int LOOP_CRYSTAL_PLACE_DELAY_MS = 200;    // 0xc8 at 0x14012fa38

    public SlowHitCrystalMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Slow Hit Crystal", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int obsidianSlotKey = getSlotVirtualKeyCode("Obsidian Slot");
        int crystalSlotKey = getSlotVirtualKeyCode("Crystal Slot");

        inputController.pressKey(obsidianSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(crystalSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(INITIAL_CRYSTAL_BREAK_DELAY_MS);
        inputController.clickMouse("left");

        while (inputController.isKeyHeldDown(triggerKeyCode)) {
            inputController.clickMouse("right");
            inputController.sleepMillis(LOOP_CRYSTAL_PLACE_DELAY_MS);
            inputController.clickMouse("left");
            inputController.sleepMillis(delayMs);
        }
    }
}
