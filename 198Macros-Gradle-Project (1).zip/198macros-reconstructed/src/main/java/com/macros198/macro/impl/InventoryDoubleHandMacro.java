package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class InventoryDHand} (RTTI {@code 0x14054a9e8}, vtable {@code 0x140507108},
 * {@code execute} at {@code 0x14012e1e0}).
 *
 * <p>Exact execution sequence in {@code 0x14012e1e0}:
 * <ol>
 *   <li>Read {@code "Totem Slot"} ({@code ebx}).</li>
 *   <li>Press {@code totemSlot} immediately when the user opens their inventory.</li>
 * </ol>
 */
public final class InventoryDoubleHandMacro extends AbstractMacro {
    public InventoryDoubleHandMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Inventory D-Hand", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int totemSlotKey = getSlotVirtualKeyCode("Totem Slot");
        inputController.pressKey(totemSlotKey);
    }
}
