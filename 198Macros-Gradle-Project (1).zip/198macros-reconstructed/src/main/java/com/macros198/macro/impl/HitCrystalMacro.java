package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class HitCrystal} (RTTI {@code 0x14054ae68}, vtable {@code 0x14050fa18},
 * {@code execute} at {@code 0x14016d930}).
 *
 * <p>Exact execution sequence in {@code 0x14016d930}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Obsidian Slot"} ({@code edi}), and {@code "Crystal Slot"} ({@code esi}).</li>
 *   <li>Press {@code obsidianSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code crystalSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Left-click to detonate the placed End Crystal.</li>
 *   <li>While {@code GetAsyncKeyState(triggerKeyCode) < 0} ({@code 0x14016dd0e} / {@code 0x14016ddff}):
 *     <ul>
 *       <li>Right-click (place crystal), sleep {@code delay} ms.</li>
 *       <li>Left-click (break crystal), sleep {@code delay} ms.</li>
 *     </ul>
 *   </li>
 * </ol>
 */
public final class HitCrystalMacro extends AbstractMacro {
    public HitCrystalMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Hit Crystal", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int obsidianSlotKey = getSlotVirtualKeyCode("Obsidian Slot");
        int crystalSlotKey = getSlotVirtualKeyCode("Crystal Slot");

        inputController.pressKey(obsidianSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(crystalSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.clickMouse("left");

        while (inputController.isKeyHeldDown(triggerKeyCode)) {
            inputController.clickMouse("right");
            inputController.sleepMillis(delayMs);
            inputController.clickMouse("left");
            inputController.sleepMillis(delayMs);
        }
    }
}
