package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class BreachSwap} (RTTI {@code 0x14054a950}, vtable {@code 0x140507008},
 * {@code onMouseClick} at {@code 0x14012d400}).
 *
 * <p>Unlike the other 13 macros which override {@code vtable[1]} ({@code onKeyPress}),
 * {@code BreachSwap} overrides {@code vtable[2]} ({@code onMouseClick}) at {@code 0x14012d400}:
 * <ol>
 *   <li>Checks {@code cmp edx, 1; jne exit} ({@code mouseButton == 1}, left mouse button).</li>
 *   <li>Reads {@code delay} ({@code ebx}), {@code "Mace Slot"} ({@code esi}), and {@code "Sword Slot"} ({@code edi}).</li>
 *   <li>Presses {@code maceSlot} immediately during the attack swing to apply Mace Breach armor penetration.</li>
 *   <li>Sleeps {@code delay} ms (if {@code > 0}).</li>
 *   <li>Presses {@code swordSlot} to return to the sword.</li>
 * </ol>
 */
public final class BreachSwapMacro extends AbstractMacro {
    public static final int LEFT_MOUSE_BUTTON = 1;

    public BreachSwapMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Breach Swap", MacroCategory.MACE, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        onMouseClick(LEFT_MOUSE_BUTTON);
    }

    @Override
    public void onMouseClick(int mouseButton) {
        if (mouseButton != LEFT_MOUSE_BUTTON) {
            return;
        }
        int delayMs = getConfiguredDelayMs();
        int maceSlotKey = getSlotVirtualKeyCode("Mace Slot");
        int swordSlotKey = getSlotVirtualKeyCode("Sword Slot");

        inputController.pressKey(maceSlotKey);
        inputController.sleepMillis(delayMs);
        inputController.pressKey(swordSlotKey);
    }
}
