package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class AnchorPearl} (RTTI {@code 0x14054a8e0}, vtable {@code 0x140506f58},
 * {@code execute} at {@code 0x14012c940}).
 *
 * <p>Exact execution sequence in {@code 0x14012c940}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Anchor Slot"} ({@code r14d}),
 *       {@code "Glowstone Slot"} ({@code edi}), and {@code "Pearl Slot"} ({@code esi}).</li>
 *   <li>Press {@code anchorSlot}, right-click, and sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code glowstoneSlot}, right-click, and sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code pearlSlot}, right-click, sleep {@code 50} ms ({@code 0x32} at {@code 0x14012ce54}),
 *       and right-click again to explode the anchor and throw the ender pearl immediately.</li>
 * </ol>
 */
public final class AnchorPearlMacro extends AbstractMacro {
    private static final int PEARL_FOLLOWUP_DELAY_MS = 50; // 0x32 at 0x14012ce54

    public AnchorPearlMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Anchor Pearl", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int anchorSlotKey = getSlotVirtualKeyCode("Anchor Slot");
        int glowstoneSlotKey = getSlotVirtualKeyCode("Glowstone Slot");
        int pearlSlotKey = getSlotVirtualKeyCode("Pearl Slot");

        inputController.pressKey(anchorSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(glowstoneSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(pearlSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(PEARL_FOLLOWUP_DELAY_MS);
        inputController.clickMouse("right");
    }
}
