package com.macros198.macro;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.impl.AnchorPearlMacro;
import com.macros198.macro.impl.AutoShieldBreakerMacro;
import com.macros198.macro.impl.BreachSwapMacro;
import com.macros198.macro.impl.DoubleAnchorMacro;
import com.macros198.macro.impl.ElytraSwapMacro;
import com.macros198.macro.impl.FastXpMacro;
import com.macros198.macro.impl.HitCrystalMacro;
import com.macros198.macro.impl.InventoryDoubleHandMacro;
import com.macros198.macro.impl.KeyPearlMacro;
import com.macros198.macro.impl.OffhandHotbarTotemMacro;
import com.macros198.macro.impl.PearlCatchMacro;
import com.macros198.macro.impl.SingleAnchorMacro;
import com.macros198.macro.impl.SlowHitCrystalMacro;
import com.macros198.macro.impl.StunSlamMacro;
import java.util.Collections;
import java.util.List;

/**
 * Factory and registry of all 14 combat macro implementations, reconstructed in the exact
 * instantiation order of {@code 0x14016df20} ({@code 0x14016df74}–{@code 0x14016e9a4}).
 */
public final class MacroRegistry {
    private final List<AbstractMacro> macros;

    public MacroRegistry(ConfigurationManager configManager, InputSimulationController inputController) {
        this.macros = List.of(
                new HitCrystalMacro(configManager, inputController),
                new SingleAnchorMacro(configManager, inputController),
                new DoubleAnchorMacro(configManager, inputController),
                new AnchorPearlMacro(configManager, inputController),
                new SlowHitCrystalMacro(configManager, inputController),
                new KeyPearlMacro(configManager, inputController),
                new InventoryDoubleHandMacro(configManager, inputController),
                new OffhandHotbarTotemMacro(configManager, inputController),
                new FastXpMacro(configManager, inputController),
                new StunSlamMacro(configManager, inputController),
                new PearlCatchMacro(configManager, inputController),
                new ElytraSwapMacro(configManager, inputController),
                new BreachSwapMacro(configManager, inputController),
                new AutoShieldBreakerMacro(configManager, inputController));
    }

    public List<AbstractMacro> getMacros() {
        return Collections.unmodifiableList(macros);
    }

    public AbstractMacro findByName(String name) {
        for (AbstractMacro macro : macros) {
            if (macro.getName().equalsIgnoreCase(name)) {
                return macro;
            }
        }
        return null;
    }
}
