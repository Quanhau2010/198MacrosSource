package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class PearlCatch} (RTTI {@code 0x14054aa60}, vtable {@code 0x1405071e8},
 * {@code execute} at {@code 0x14012eb00}).
 *
 * <p>Exact execution sequence in {@code 0x14012eb00}:
 * <ol>
 *   <li>Read {@code delay} ({@code r14d}), {@code "Pearl slot"} ({@code edi}), and {@code "Wind Charge Slot"} ({@code ebx}).</li>
 *   <li>Press {@code pearlSlot} and right-click.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code windChargeSlot} and right-click.</li>
 * </ol>
 */
public final class PearlCatchMacro extends AbstractMacro {
    public PearlCatchMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Pearl Catch", MacroCategory.MACE, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int pearlSlotKey = getSlotVirtualKeyCode("Pearl slot");
        int windChargeSlotKey = getSlotVirtualKeyCode("Wind Charge Slot");

        inputController.pressKey(pearlSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);
        inputController.pressKey(windChargeSlotKey);
        inputController.clickMouse("right");
    }
}
