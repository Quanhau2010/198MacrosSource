package com.macros198.macro;

import com.macros198.config.ConfigurationManager;
import com.macros198.config.MacroConfiguration;
import com.macros198.input.InputSimulationController;
import com.macros198.input.KeybindMapper;
import com.macros198.model.MacroCategory;

/**
 * Base class for all 14 combat macros in 198Macros v1.4.0.
 *
 * <p>Reconstructed from {@code class Macro} (RTTI TypeDescriptor {@code 0x14054a908},
 * vtable {@code 0x140506f78}) and its helper methods:
 * <ul>
 *   <li>{@code 0x14012c190}: Virtual scalar deleting destructor</li>
 *   <li>{@code 0x14012c1d0}: {@code getSettingString(macroName, settingKey)}</li>
 *   <li>{@code 0x14012c6f0}: {@code getDelaySetting(macroName, "delay")} (base-10 {@code strtol})</li>
 *   <li>{@code 0x14012c890}: {@code getSlotVirtualKeyCode(macroName, slotName)}</li>
 *   <li>{@code 0x140118d90}: No-op default virtual handler for mouse/key events</li>
 * </ul>
 */
public abstract class AbstractMacro {
    private final String name;
    private final MacroCategory category;
    protected final ConfigurationManager configManager;
    protected final InputSimulationController inputController;

    protected AbstractMacro(
            String name,
            MacroCategory category,
            ConfigurationManager configManager,
            InputSimulationController inputController) {
        this.name = name;
        this.category = category;
        this.configManager = configManager;
        this.inputController = inputController;
    }

    public final String getName() {
        return name;
    }

    public final MacroCategory getCategory() {
        return category;
    }

    public final MacroConfiguration getConfiguration() {
        return configManager.getMacroConfig(name);
    }

    /**
     * Reads the integer delay (in milliseconds) configured for this macro,
     * reconstructed from {@code 0x14012c6f0(this->name, "delay")}.
     */
    protected final int getConfiguredDelayMs() {
        MacroConfiguration cfg = getConfiguration();
        return cfg != null ? cfg.getDelayMs() : 0;
    }

    /**
     * Resolves a named slot binding (e.g., {@code "Anchor Slot"}, {@code "Crystal Slot"})
     * into its corresponding Virtual Key code, reconstructed from {@code 0x14012c890}
     * ({@code 0x14012c1d0} + {@code 0x1401291c0}).
     */
    protected final int getSlotVirtualKeyCode(String slotName) {
        MacroConfiguration cfg = getConfiguration();
        if (cfg == null) {
            return KeybindMapper.VK_NONE;
        }
        String boundKeyName = cfg.getSlotValue(slotName);
        return KeybindMapper.toVirtualKeyCode(boundKeyName);
    }

    /**
     * Virtual method slot 1 ({@code vtable[1]}): Invoked when the macro's keybind is pressed.
     *
     * @param triggerKeyCode the virtual key code that triggered the macro
     */
    public void onKeyPress(int triggerKeyCode) {
        // Default no-op (0x140118d90) for macros that only respond to mouse clicks (e.g. BreachSwap)
    }

    /**
     * Virtual method slot 2 ({@code vtable[2]}): Invoked when a mouse button is clicked.
     *
     * @param mouseButton 1 for left button, 2 for right button
     */
    public void onMouseClick(int mouseButton) {
        // Default no-op (0x140118d90) for macros that only respond to keybinds
    }
}
