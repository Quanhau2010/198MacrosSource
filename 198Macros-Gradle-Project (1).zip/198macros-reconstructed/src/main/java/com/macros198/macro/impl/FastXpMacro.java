package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Reconstructed from {@code class FastXP} (RTTI {@code 0x14054a9c8}, vtable {@code 0x1405070c0},
 * {@code execute} at {@code 0x14012e040}).
 *
 * <p>Exact execution sequence in {@code 0x14012e040}:
 * <ol>
 *   <li>Read {@code delay} ({@code esi}).</li>
 *   <li>While {@code GetAsyncKeyState(triggerKeyCode) < 0} ({@code 0x14012e0d3} / {@code 0x14012e181}):
 *     <ul>
 *       <li>Right-click ({@code clickMouse("right")}).</li>
 *       <li>Compute random jitter {@code (rand() % 11) - 5} (range {@code [-5, +5]} ms) at {@code 0x14012e14e}.</li>
 *       <li>Sleep {@code delay + jitter} ms (if {@code > 0}).</li>
 *     </ul>
 *   </li>
 * </ol>
 */
public final class FastXpMacro extends AbstractMacro {
    public FastXpMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Fast XP", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int baseDelayMs = getConfiguredDelayMs();
        do {
            inputController.clickMouse("right");
            int jitterMs = ThreadLocalRandom.current().nextInt(-5, 6);
            int effectiveDelayMs = baseDelayMs + jitterMs;
            if (effectiveDelayMs > 0) {
                inputController.sleepMillis(effectiveDelayMs);
            }
        } while (inputController.isKeyHeldDown(triggerKeyCode));
    }
}
