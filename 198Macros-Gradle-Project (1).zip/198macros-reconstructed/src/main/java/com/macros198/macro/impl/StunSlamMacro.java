package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class StunSlam} (RTTI {@code 0x14054aad8}, vtable {@code 0x1405072a0},
 * {@code execute} at {@code 0x14012fbd0}).
 *
 * <p>Note: In {@code 0x14012fc8d}, the string {@code "Axe slot"} is constructed on the stack via
 * {@code movabs rax, 0x746f6c7320657841}.
 *
 * <p>Exact execution sequence in {@code 0x14012fbd0}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Axe slot"} ({@code esi}), and {@code "Mace Slot"} ({@code edi}).</li>
 *   <li>Press {@code axeSlot} and left-click to stun the opponent's shield.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Press {@code maceSlot}.</li>
 *   <li>While {@code GetAsyncKeyState(triggerKeyCode) < 0} ({@code 0x14012fec0} / {@code 0x14012ff3b}):
 *     <ul>
 *       <li>Left-click with the Mace and sleep {@code delay} ms.</li>
 *     </ul>
 *   </li>
 * </ol>
 */
public final class StunSlamMacro extends AbstractMacro {
    public StunSlamMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Stun Slam", MacroCategory.MACE, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int axeSlotKey = getSlotVirtualKeyCode("Axe slot");
        int maceSlotKey = getSlotVirtualKeyCode("Mace Slot");

        inputController.pressKey(axeSlotKey);
        inputController.clickMouse("left");
        inputController.sleepMillis(delayMs);
        inputController.pressKey(maceSlotKey);

        while (inputController.isKeyHeldDown(triggerKeyCode)) {
            inputController.clickMouse("left");
            inputController.sleepMillis(delayMs);
        }
    }
}
