package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class DoubleAnchor} (RTTI {@code 0x14054a978}, vtable {@code 0x140507050},
 * {@code execute} at {@code 0x14012d610}).
 *
 * <p>Exact execution sequence in {@code 0x14012d610}:
 * <ol>
 *   <li>Read {@code delay} ({@code ebx}), {@code "Anchor Slot"} ({@code esi}),
 *       {@code "Glowstone Slot"} ({@code edi}), and {@code "Totem/Explode Slot"} ({@code r15d}).</li>
 *   <li>Press {@code anchorSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code glowstoneSlot}, right-click, sleep {@code delay} ms.</li>
 *   <li>Press {@code anchorSlot}, right-click (detonates first anchor), then immediately press
 *       {@code anchorSlot} and right-click again (places second anchor), sleep {@code delay} ms.</li>
 *   <li>Press {@code glowstoneSlot}, right-click (charges second anchor), sleep {@code delay} ms.</li>
 *   <li>Press {@code totemExplodeSlot}, right-click (detonates second anchor while holding totem).</li>
 * </ol>
 */
public final class DoubleAnchorMacro extends AbstractMacro {
    public DoubleAnchorMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Double Anchor", MacroCategory.CRYSTAL, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int anchorSlotKey = getSlotVirtualKeyCode("Anchor Slot");
        int glowstoneSlotKey = getSlotVirtualKeyCode("Glowstone Slot");
        int totemExplodeSlotKey = getSlotVirtualKeyCode("Totem/Explode Slot");

        // First anchor placement & charge
        inputController.pressKey(anchorSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        inputController.pressKey(glowstoneSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        // Detonate first anchor & immediately place second anchor
        inputController.pressKey(anchorSlotKey);
        inputController.clickMouse("right");
        inputController.pressKey(anchorSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        // Charge second anchor
        inputController.pressKey(glowstoneSlotKey);
        inputController.clickMouse("right");
        inputController.sleepMillis(delayMs);

        // Swap to totem/explode slot and detonate second anchor
        inputController.pressKey(totemExplodeSlotKey);
        inputController.clickMouse("right");
    }
}
