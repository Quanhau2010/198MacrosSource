package com.macros198.macro.impl;

import com.macros198.config.ConfigurationManager;
import com.macros198.input.InputSimulationController;
import com.macros198.macro.AbstractMacro;
import com.macros198.model.MacroCategory;

/**
 * Reconstructed from {@code class ElytraSwap} (RTTI {@code 0x14054a9a0}, vtable {@code 0x140507070},
 * {@code execute} at {@code 0x14012dd70}).
 *
 * <p>Exact execution sequence in {@code 0x14012dd70}:
 * <ol>
 *   <li>Read {@code delay} ({@code edi}) and {@code "Elytra/Chestplate Slot"} ({@code ebx}).</li>
 *   <li>Press {@code elytraChestplateSlot}.</li>
 *   <li>Sleep {@code delay} ms (if {@code > 0}).</li>
 *   <li>Right-click to equip the chestplate/elytra from hotbar.</li>
 * </ol>
 */
public final class ElytraSwapMacro extends AbstractMacro {
    public ElytraSwapMacro(ConfigurationManager configManager, InputSimulationController inputController) {
        super("Elytra Swap", MacroCategory.MACE, configManager, inputController);
    }

    @Override
    public void onKeyPress(int triggerKeyCode) {
        int delayMs = getConfiguredDelayMs();
        int elytraSlotKey = getSlotVirtualKeyCode("Elytra/Chestplate Slot");

        inputController.pressKey(elytraSlotKey);
        inputController.sleepMillis(delayMs);
        inputController.clickMouse("right");
    }
}
