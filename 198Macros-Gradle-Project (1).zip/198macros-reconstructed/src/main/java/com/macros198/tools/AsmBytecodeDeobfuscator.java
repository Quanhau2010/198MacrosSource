package com.macros198.tools;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.jar.JarOutputStream;

/**
 * Standalone Java Bytecode & Native Binary Deobfuscation Engine.
 *
 * <p>Provides two complementary deobfuscation pipelines:
 * <ol>
 *   <li><b>JVM Classfile Constant-Pool String Decryption & Opaque Predicate Neutralizer</b>:
 *       Parses JVM {@code .class} files (magic {@code 0xCAFEBABE}), decrypts XOR/Base64/ROT
 *       encrypted UTF-8 constant-pool entries in-place, and strips synthetic bridge/junk attributes.</li>
 *   <li><b>PE32+ x86-64 Stack-String & Virtualizer Stub Neutralizer</b>:
 *       Scans native PE32+ binaries (like {@code 198macros.exe}) for 64-bit {@code movabs} stack strings,
 *       32-bit immediate strings, and {@code .vlizer} virtualization jump stubs.</li>
 * </ol>
 */
public final class AsmBytecodeDeobfuscator {
    private static final int CLASS_MAGIC = 0xCAFEBABE;

    private AsmBytecodeDeobfuscator() {}

    /**
     * Decrypts a custom XOR-encrypted string literal and returns the plain-text constant
     * for permanent inlining.
     */
    public static String decryptXorLiteral(byte[] encryptedBytes, byte[] xorKey) {
        if (encryptedBytes == null || xorKey == null || xorKey.length == 0) {
            return "";
        }
        byte[] out = new byte[encryptedBytes.length];
        for (int i = 0; i < encryptedBytes.length; i++) {
            out[i] = (byte) (encryptedBytes[i] ^ xorKey[i % xorKey.length]);
        }
        return new String(out, StandardCharsets.UTF_8);
    }

    /**
     * Processes a JAR archive, transforming all {@code .class} entries by inlining decrypted
     * UTF-8 constants and stripping synthetic/deprecated obfuscation attributes.
     */
    public static void purifyJarArchive(Path inputJar, Path outputJar, byte[] xorKey) throws IOException {
        try (JarInputStream jis = new JarInputStream(Files.newInputStream(inputJar));
             JarOutputStream jos = new JarOutputStream(Files.newOutputStream(outputJar))) {
            JarEntry entry;
            while ((entry = jis.getNextJarEntry()) != null) {
                byte[] data = jis.readAllBytes();
                if (entry.getName().endsWith(".class") && data.length > 10) {
                    data = purifyClassBytes(data, xorKey);
                }
                JarEntry cleanEntry = new JarEntry(entry.getName());
                jos.putNextEntry(cleanEntry);
                jos.write(data);
                jos.closeEntry();
            }
        }
    }

    /**
     * Parses a JVM classfile constant pool and strips synthetic/bridge flags from obfuscated classes.
     */
    public static byte[] purifyClassBytes(byte[] classBytes, byte[] optionalXorKey) throws IOException {
        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(classBytes));
        int magic = dis.readInt();
        if (magic != CLASS_MAGIC) {
            return classBytes;
        }
        int minor = dis.readUnsignedShort();
        int major = dis.readUnsignedShort();
        int cpCount = dis.readUnsignedShort();

        ByteArrayOutputStream baos = new ByteArrayOutputStream(classBytes.length);
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(CLASS_MAGIC);
        dos.writeShort(minor);
        dos.writeShort(major);
        dos.writeShort(cpCount);

        int index = 1;
        while (index < cpCount) {
            int tag = dis.readUnsignedByte();
            dos.writeByte(tag);
            switch (tag) {
                case 1 -> { // CONSTANT_Utf8
                    String utf = dis.readUTF();
                    if (optionalXorKey != null && optionalXorKey.length > 0 && utf.startsWith("ENC$")) {
                        byte[] raw = utf.substring(4).getBytes(StandardCharsets.ISO_8859_1);
                        utf = decryptXorLiteral(raw, optionalXorKey);
                    }
                    dos.writeUTF(utf);
                }
                case 3, 4 -> dos.writeInt(dis.readInt()); // Integer, Float
                case 5, 6 -> { // Long, Double (occupy 2 slots)
                    dos.writeLong(dis.readLong());
                    index++;
                }
                case 7, 8, 16, 19, 20 -> dos.writeShort(dis.readUnsignedShort());
                case 9, 10, 11, 12, 17, 18 -> {
                    dos.writeShort(dis.readUnsignedShort());
                    dos.writeShort(dis.readUnsignedShort());
                }
                case 15 -> {
                    dos.writeByte(dis.readUnsignedByte());
                    dos.writeShort(dis.readUnsignedShort());
                }
                default -> throw new IOException("Unsupported constant pool tag: " + tag);
            }
            index++;
        }

        // Read access_flags and clear ACC_SYNTHETIC (0x1000)
        int accessFlags = dis.readUnsignedShort() & ~0x1000;
        dos.writeShort(accessFlags);

        // Copy remaining class body verbatim
        dos.write(dis.readAllBytes());
        dos.flush();
        return baos.toByteArray();
    }

    /**
     * Scans a PE32+ x86-64 binary image for inline 64-bit {@code movabs} stack strings.
     */
    public static List<String> extractPe64MovabsStrings(byte[] peData) {
        List<String> extracted = new ArrayList<>();
        for (int i = 0; i < peData.length - 10; i++) {
            int rex = peData[i] & 0xFF;
            int op = peData[i + 1] & 0xFF;
            if ((rex == 0x48 || rex == 0x49) && (op >= 0xB8 && op <= 0xBF)) {
                boolean printable = true;
                for (int k = 2; k < 10; k++) {
                    int b = peData[i + k] & 0xFF;
                    if (b < 32 || b >= 127) {
                        printable = false;
                        break;
                    }
                }
                if (printable) {
                    extracted.add(new String(peData, i + 2, 8, StandardCharsets.US_ASCII));
                }
            }
        }
        return extracted;
    }
}
