package com.macros198;

import com.macros198.config.ConfigurationManager;
import com.macros198.config.MacroConfiguration;
import com.macros198.input.GlobalInputDispatcher;
import com.macros198.input.InputSimulationController;
import com.macros198.input.KeybindMapper;
import com.macros198.macro.AbstractMacro;
import com.macros198.macro.MacroRegistry;
import com.macros198.ui.MacroDashboardFrame;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import javax.swing.SwingUtilities;

/**
 * Clean, deobfuscated application entry point for 198 Macros v1.4.0.
 *
 * <p>Reconstructed from {@code WinMain} at {@code 0x14015c6b0}:
 * <ul>
 *   <li>All {@code VMAware::detect} hypervisor checks ({@code 0x14014ab60}) have been eradicated.</li>
 *   <li>All 25 {@code NtQueryInformationProcess} anti-debug checks ({@code 0x14015d540}) have been eradicated.</li>
 *   <li>All HWID fingerprinting ({@code 0x1401133d0}), remote {@code /hwidLogin} ({@code 0x14017b7c0}),
 *       and {@code /validateSession} ({@code 0x14017c2f0}) virtualization stubs have been eradicated.</li>
 *   <li>Installs the global Win32 low-level keyboard/mouse hooks ({@code WH_KEYBOARD_LL = 13},
 *       {@code WH_MOUSE_LL = 14}) via {@code Win32NativeBridge} and launches the desktop UI.</li>
 * </ul>
 */
public final class MainApplication {
    private MainApplication() {}

    public static void main(String[] args) {
        ConfigurationManager configManager = new ConfigurationManager();
        try {
            configManager.loadFromFile();
        } catch (IOException ignored) {
        }

        InputSimulationController inputController = new InputSimulationController();
        MacroRegistry macroRegistry = new MacroRegistry(configManager, inputController);
        GlobalInputDispatcher inputDispatcher =
                new GlobalInputDispatcher(configManager, macroRegistry, inputController);

        if (args.length > 0 && "--verify-self-test".equals(args[0])) {
            runSelfVerification(macroRegistry, inputController);
            inputDispatcher.close();
            return;
        }

        if (GraphicsEnvironment.isHeadless()) {
            System.out.println("198 Macros v1.4.0 (Purified Edition) initialized in headless mode.");
            runSelfVerification(macroRegistry, inputController);
            inputDispatcher.close();
            return;
        }

        // Start global Win32 Low-Level Keyboard & Mouse hooks (0x14015c7df & 0x14015c808)
        inputDispatcher.startNativeHooks();
        Runtime.getRuntime().addShutdownHook(new Thread(inputDispatcher::close));

        SwingUtilities.invokeLater(() -> {
            MacroDashboardFrame frame =
                    new MacroDashboardFrame(configManager, macroRegistry, inputDispatcher);
            frame.setVisible(true);
        });
    }

    private static void runSelfVerification(
            MacroRegistry macroRegistry,
            InputSimulationController inputController) {
        inputController.setDryRunMode(true);
        System.out.println("=== 198 Macros v1.4.0 Purified Self-Verification ===");
        System.out.println("Loaded Macros: " + macroRegistry.getMacros().size());
        for (AbstractMacro macro : macroRegistry.getMacros()) {
            MacroConfiguration cfg = macro.getConfiguration();
            inputController.clearRecordedEventLog();
            int triggerKey = KeybindMapper.toVirtualKeyCode("R");
            if ("Breach Swap".equals(macro.getName())) {
                macro.onMouseClick(1);
            } else {
                macro.onKeyPress(triggerKey);
            }
            System.out.printf(
                    "  [OK] %-22s | Badge: %-3s | Category: %-7s | Default Delay: %2dms | Events: %s%n",
                    macro.getName(),
                    cfg.getBadgeCode(),
                    macro.getCategory().getShortLabel(),
                    cfg.getDelayMs(),
                    inputController.getRecordedEventLog());
        }
    }
}
